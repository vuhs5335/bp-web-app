  package com.hersa.app;
  public final class TablePrefix {    
      public static final String PREFIX = "";
      private TablePrefix() {
      }
  } 
