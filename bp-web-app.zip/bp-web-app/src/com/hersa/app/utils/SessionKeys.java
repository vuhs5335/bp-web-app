package com.hersa.app.utils;

public class SessionKeys {

	public static final String USER = "hersa.app.session.user";
	public static final String USER_MANAGER = "hersa.app.session.user.man";
	
	public static final String ACTIVE_BP_READING = "hersa.app.session.act.bp.reading";
}
