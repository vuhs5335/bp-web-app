package com.hersa.app.faces.admin;

import java.io.Serializable;

import com.hersa.app.faces.FacesPage;

public class ApiToolPage extends FacesPage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5978450206709754368L;

	public ApiToolPage() {
		super("API Tools");
	}
}
